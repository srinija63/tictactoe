const cells = document.querySelectorAll(".cell");
const statusText = document.getElementById("status");
const resetButton = document.getElementById("reset");

let currentPlayer = "X";
let gameState = Array(9).fill(""); // Represents the board

// Winning combinations
const winningConditions = [
    [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
    [0, 3, 6], [1, 4, 7], [2, 5, 8], // Columns
    [0, 4, 8], [2, 4, 6]             // Diagonals
];

// Initialize the game
function startGame() {
    cells.forEach((cell, index) => {
        cell.textContent = "";
        cell.addEventListener("click", () => handleCellClick(index), { once: true });
    });
    gameState.fill("");
    currentPlayer = "X";
    statusText.textContent = `Player ${currentPlayer}'s turn`;
}

// Handle a cell click
function handleCellClick(index) {
    gameState[index] = currentPlayer;
    cells[index].textContent = currentPlayer;

    if (checkWinner()) {
        statusText.textContent = `Player ${currentPlayer} wins!`;
        return;
    }

    if (!gameState.includes("")) {
        statusText.textContent = "It's a draw!";
        return;
    }

    currentPlayer = currentPlayer === "X" ? "O" : "X";
    statusText.textContent = `Player ${currentPlayer}'s turn`;
}

// Check if the current player has won
function checkWinner() {
    return winningConditions.some(condition =>
        condition.every(index => gameState[index] === currentPlayer)
    );
}

// Restart the game
resetButton.addEventListener("click", startGame);

// Start the game for the first time
startGame();
